
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const HTTP_PORT = process.env.PORT || 8080;

// Add support for incoming JSON entities
app.use(bodyParser.json());

// Array of strings (products)
let products = ['Phone', 'Blender', 'Shirt', 'Pants', 'Shoe', 'TV'];

// Deliver the app's home page to browser clients
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '/index.html'));
});

// Get all products - You can sort this array if needed
app.get('/api/items', (req, res) => {
  res.json(products);
});

// Get one product by ID
app.get('/api/items/:itemId', (req, res) => {
  const itemId = req.params.itemId;
  if (itemId >= 0 && itemId < products.length) {
    res.json({ product: products[itemId] });
  } else {
    res.status(404).send('Resource not found');
  }
});

// Add new product
app.post('/api/items', (req, res) => {
  const newItem = req.body.productName;
  products.push(newItem);
  res.status(201).json({ message: `Added ${newItem} as item identifier ${products.length - 1}` });
});

// Edit existing product by ID
app.put('/api/items/:id', (req, res) => {
  const itemId = req.params.id;
  if (itemId >= 0 && itemId < products.length) {
    const updatedItem = req.body.productName;
    products[itemId] = updatedItem;
    res.json({ message: `Updated item with identifier: ${itemId} to ${updatedItem}` });
  } else {
    res.status(404).send('Resource not found');
  }
});

// Delete product by ID
app.delete('/api/items/:id', (req, res) => {
  const itemId = req.params.id;
  if (itemId >= 0 && itemId < products.length) {
    const deletedItem = products.splice(itemId, 1)[0];
    res.status(200).json({ message: `Deleted product: ${deletedItem}` });
  } else {
    res.status(404).send('Resource not found');
  }
});

// Resource not found (this should be at the end)
app.use((req, res) => {
  res.status(404).send('Resource not found');
});

// Tell the app to start listening for requests
app.listen(HTTP_PORT, () => {
  console.log('Ready to handle requests on port ' + HTTP_PORT);
});

